# sb_statistic_01.py
import numpy as np 
import pandas as pd 

#--- 描述性統計數據
def descrStat(gpdf,fld):
    # 以下碼可以用一行 df.describe() 代替之
    SL_min  = gpdf[fld].min()
    SL_max  = gpdf[fld].max()
    SL_mean = gpdf[fld].mean()
    SL_std  = gpdf[fld].std()
    SL_median = gpdf[fld].median()
    SL_var  = gpdf[fld].var()
    SL_q25  = gpdf[fld].quantile(.25)
    SL_q50  = gpdf[fld].quantile(.50)
    SL_q75  = gpdf[fld].quantile(.75) 
    
    print('%s : min %.5f max %.5f mean %.5f std %.5f var %.5f'
          % (fld,SL_min,SL_max,SL_mean, SL_std, SL_var))
    print('median %.5f 25qunatile %.5f 50qunatile %.5f 75qunatile %.5f'
          % (SL_median, SL_q25, SL_q50, SL_q75))
    

''' Step 1. 以dataframe 讀取csv '''
print('以dataframe 讀取 csv')
df = pd.read_csv('irisSeaborn.csv')
#print(f'df.shape : {df.shape}')
#print(f'欄位: {df.columns}')
#print(f'前5筆記錄: {df.head()}')

''' Step 2. Describe '''
# 只選 setosa這組
df0 = df[df['species']=='setosa']
print('setosa組，統計數據如下：')
print(df0.describe())
#descrStat(df0,'sepal_length')     # 回報統計數據
df0Stat = df0.describe()
print(df0Stat.iloc[:,0])
# 只選 versicolor這組
df1 = df[df['species']=='versicolor']
# 只選 virginica這組
df2 = df[df['species']=='virginica']


''' Step 3. 畫個Box圖 觀察離散程度 min mean max percentile '''
import seaborn as sns
import matplotlib.pyplot as plt  

# 把三組畫在一起
fig,axes = plt.subplots(1,3,sharey=True,figsize=(10,6))

axes[0].set_title('setosa')
axes[1].set_title('versicolor')
axes[2].set_title('virginica')

fig.autofmt_xdate(rotation=45)
sns.boxplot(data=df0,ax=axes[0])
sns.boxplot(data=df1,ax=axes[1])
sns.boxplot(data=df2,ax=axes[2])

fig.savefig('iris_box.jpg')

''' Step 4. 畫 histogram  '''
#--- 接收參數 fld: field name / jpg: jpgfilename  /NS: normal distribution  
def histo(fld,vcolor,jpg,NS):
    #--- hitogram distribution plot
    fig,axes = plt.subplots(1,3,sharex=True,sharey=True,figsize=(10,6))
    #fig,axes = plt.subplots(1,3,figsize=(10,6))
    axes[0].set_title('setosa')
    axes[1].set_title('versicolor')
    axes[2].set_title('virginica')
    
    sns.histplot(color=vcolor,data= df0,x=df0[fld],ax=axes[0],stat=NS)
    sns.histplot(color=vcolor,data= df1,x=df1[fld],ax=axes[1],stat=NS)
    sns.histplot(color=vcolor,data= df2,x=df2[fld],ax=axes[2],stat=NS)
    
    fig.savefig(jpg)

#--- plot hitogram distribution 計數
histo('sepal_length','skyblue','iris_histSL_C.jpg','count')
histo('sepal_width','orange','iris_histSW_C.jpg','count')
histo('petal_length','green','iris_histPL_C.jpg','count')
histo('petal_width','red','iris_histPW_C.jpg','count')

#--- plot hitogram probability density  
histo('sepal_length','skyblue','iris_histSL_D.jpg','density')
histo('sepal_width','orange','iris_histSW_D.jpg','density')
histo('petal_length','green','iris_histPL_D.jpg','density')
histo('petal_width','red','iris_histPW_D.jpg','density')


''' Step 5.  check if Normal distribution   '''
import scipy.stats

def checkNS(vList):
    _,pValue = scipy.stats.shapiro(vList)
    return pValue

print(checkNS(df0['sepal_length']))
print(checkNS(df0['sepal_width']))

''' 略  '''
''' Step 6. ANOVA test '''
dat0 = df0['sepal_length']
dat1 = df1['sepal_length']
dat2 = df2['sepal_length']

_,pANOVA = scipy.stats.f_oneway(dat0, dat1, dat2)

if pANOVA<=0.05:
    print('p value= %.6f '% pANOVA)
    
